﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Priya_Final_Project.Models;

namespace Priya_Final_Project.Data
{
    public class ProductContext : DbContext
    {
        public ProductContext (DbContextOptions<ProductContext> options)
            : base(options)
        {
        }

        public DbSet<Priya_Final_Project.Models.Genre> Genre { get; set; }

        public DbSet<Priya_Final_Project.Models.ProductCatelogue> ProductCatelogue { get; set; }

        public DbSet<Priya_Final_Project.Models.User> User { get; set; }


         protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //to create db if it dosnt exist
            modelBuilder.Entity<Priya_Final_Project.Models.Genre>().ToTable("Genre");
            modelBuilder.Entity<Priya_Final_Project.Models.ProductCatelogue>().ToTable("ProductCatelogue");
            modelBuilder.Entity<Priya_Final_Project.Models.User>().ToTable("User");
        }


         public DbSet<Priya_Final_Project.Models.Order> Order { get; set; }
    }
}
