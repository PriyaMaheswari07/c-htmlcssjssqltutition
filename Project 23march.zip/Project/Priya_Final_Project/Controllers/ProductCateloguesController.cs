﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Priya_Final_Project.Data;
using Priya_Final_Project.Models;

namespace Priya_Final_Project.Controllers
{
    public class ProductCateloguesController : Controller
    {
        private readonly ProductContext _context;

        public ProductCateloguesController(ProductContext context)
        {
            _context = context;
        }

        // GET: ProductCatelogues
        public async Task<IActionResult> Index()
        {
            return View(await _context.ProductCatelogue.ToListAsync());
        }

        // GET: ProductCatelogues/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var productCatelogue = await _context.ProductCatelogue
                .FirstOrDefaultAsync(m => m.ProductID == id);
            if (productCatelogue == null)
            {
                return NotFound();
            }

            return View(productCatelogue);
        }

        // GET: ProductCatelogues/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: ProductCatelogues/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ProductID,ProductName,ProductImage,ProductDescription,ProductAuthor,ProductPublishedDate,ProductUnitPrice,ProductStock")] ProductCatelogue productCatelogue)
        {
            if (ModelState.IsValid)
            {
                _context.Add(productCatelogue);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(productCatelogue);
        }

        // GET: ProductCatelogues/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var productCatelogue = await _context.ProductCatelogue.FindAsync(id);
            if (productCatelogue == null)
            {
                return NotFound();
            }
            return View(productCatelogue);
        }

        // POST: ProductCatelogues/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ProductID,ProductName,ProductImage,ProductDescription,ProductAuthor,ProductPublishedDate,ProductUnitPrice,ProductStock")] ProductCatelogue productCatelogue)
        {
            if (id != productCatelogue.ProductID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(productCatelogue);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ProductCatelogueExists(productCatelogue.ProductID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(productCatelogue);
        }

        // GET: ProductCatelogues/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var productCatelogue = await _context.ProductCatelogue
                .FirstOrDefaultAsync(m => m.ProductID == id);
            if (productCatelogue == null)
            {
                return NotFound();
            }

            return View(productCatelogue);
        }

        // POST: ProductCatelogues/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var productCatelogue = await _context.ProductCatelogue.FindAsync(id);
            _context.ProductCatelogue.Remove(productCatelogue);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ProductCatelogueExists(int id)
        {
            return _context.ProductCatelogue.Any(e => e.ProductID == id);
        }
    }
}
