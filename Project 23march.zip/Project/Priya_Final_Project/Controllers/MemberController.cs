﻿using Microsoft.AspNetCore.Mvc;
using Priya_Final_Project.Data;
using Priya_Final_Project.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace Priya_Final_Project.Controllers
{
    public class MemberController : Controller
    {
        private readonly ProductContext _context;

        public MemberController(ProductContext context)
        {
            _context = context;
        }

        public IActionResult SignUp() //the he action request trigger this code in the control.cs.
                                      //it looks up for the keyword "SignUp"
        {
            return View(); //trigger the frontend "view'
                            //to render the page
        }

        public IActionResult Login()
        {
            return View();
        }


        //to create the data 
        //this is known as "binding"
        //for "sign up"
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SignUp([Bind("UserID,UserFullName,UserDOB,UserEmail,UserName,UserPassword,UserContact")] User user)
        {
            if (ModelState.IsValid)
            {
                _context.Add(user);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Login));// driect to login page
            }
            return View(user);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login([Bind("UserName,UserPassword")] User user)
        {
            if (ModelState.IsValid)
            {
                var loginUser = await _context.User.FirstOrDefaultAsync(m => m.UserName == user.UserName);
                bool isAuthenticated = false;
                if (loginUser != null)
                {
                    if (loginUser.UserPassword == user.UserPassword)
                    {
                        isAuthenticated = true;
                    }
                }

                if (isAuthenticated == true)
                {
                    return RedirectToAction("Index","Home"); //direct to  "Index.cshtml"  via going to "Home.controller" method of  public IActionResult Index()
                }
            }
            return View(user);
        }
    }
}
