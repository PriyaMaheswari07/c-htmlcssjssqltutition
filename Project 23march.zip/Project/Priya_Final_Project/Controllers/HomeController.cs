﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Priya_Final_Project.Data;
using Priya_Final_Project.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace Priya_Final_Project.Controllers
{
    public class HomeController : Controller
    {
        //private readonly ILogger<HomeController> _logger;

        //public HomeController(ILogger<HomeController> logger)
        //{
        //    _logger = logger;
        //}

        private readonly ProductContext _context;

        public HomeController(ProductContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var listofCatelogue = await _context.ProductCatelogue.ToListAsync();
            return View(listofCatelogue);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }


        //MY CODE!!
        //for Product catelogue view in /home/index
        // GET: ProductCatelogues/Details/5
        public async Task<IActionResult> ProductDetail(int? id)
        {
            //id not found
            if (id == null)
            {
                return NotFound();
            }

            //if the whole record not found
            var productCatelogue = await _context.ProductCatelogue
                .FirstOrDefaultAsync(m => m.ProductID == id);
            if (productCatelogue == null)
            {
                return NotFound();
            }

            return View(productCatelogue);
        }

    }
}
