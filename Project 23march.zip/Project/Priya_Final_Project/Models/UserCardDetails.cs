﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Priya_Final_Project.Models
{
    public class UserCardDetails
    {
        [Key]
        public User UserID { get; set; }

        public string CardName { get; set; }

        public string CardNumber { get; set; }

        [DataType(DataType.Date)]
        public DateTime CardExpire { get; set;}

       
        
    }
}
