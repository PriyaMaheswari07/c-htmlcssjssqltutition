﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Priya_Final_Project.Models
{
    public class User
    {

        //code first approach:
        //create the table in the codeitsefl, then the database table will be created.
        //no linq no query to be created
        //the table will be automatically linkedin
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public string UserID { get; set; }

        public string UserFullName { get; set; }

        [DataType(DataType.Date)]
        public DateTime UserDOB { get; set; }

        public string UserEmail { get; set; }


        public string UserName { get; set; }
        public string UserPassword { get; set; }

        public string UserContact { get; set; }

        public Genre UserPreferredGenre { get; set; }

       

    }
}
