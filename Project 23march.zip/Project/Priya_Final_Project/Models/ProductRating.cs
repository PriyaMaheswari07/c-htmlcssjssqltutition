﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Priya_Final_Project.Models
{
    public class ProductRating
    {

        [Key]

        public int ProductRatingID{ get; set; }


        public ProductCatelogue ProductCatelogue { get; set; }

        public int UserID { get; set; }


        [DataType(DataType.Date)]
        public DateTime RatingDate { get; set; }

        public int ProductRatingValue { get; set; }

       

    }
}
