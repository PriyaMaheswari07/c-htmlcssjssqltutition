﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Priya_Final_Project.Models
{
    public class ProductCatelogue
    {

        [Key]
        public int ProductID { get; set; }

        public string ProductName { get; set; }

        public string ProductImage { get; set; }

        public string ProductDescription { get; set; }

        public string ProductAuthor { get; set; }

        [DataType(DataType.Date)]
        public DateTime  ProductPublishedDate { get; set; }

        public Genre Genre { get; set; }

        public float ProductUnitPrice { get; set; }


        public int ProductStock { get; set; }

      
       

      

       

    }
}
