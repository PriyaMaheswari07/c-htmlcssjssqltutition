﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Priya_Final_Project.Models
{
    public class Order
    {
        [Key]

        public int OrderID { get; set; }

        public ProductCatelogue ProductID { get; set; }

        public User UserID { get; set; }

       
        [DataType(DataType.Date)]
        public DateTime OrderDate { get; set; }

        
        public float ProductPrice { get; set; }

        public string ProductStatus { get; set; }


    }
}
